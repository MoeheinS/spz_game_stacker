console.log('%cStacker game','color:#ff0000;font-family:Comic Sans MS;');

/*  Table of Contents
*   Constants and settings
*   Actual physics objects
*   Functions
*   Lifecycle events
*   Rendering
*/

/*
*   Constants and settings
*/
let score_global = 0;
const DROPRATE = 25;
const RAISE_RATE = 30;
const BASE_SCORE = 1000;
const GRAVITY = 0.75;

const COLOR_STACKED = '#795548';
const COLOR_GOAL = '#207828';

// create engine
var engine = Engine.create(),
    world = engine.world;
    //world.gravity.y = 0;

// create renderer
var reWi = pcWidth();
var reHi = pcHeight();
console.warn(reWi, reHi);

var render = Render.create({
    element: document.querySelector('.container__Matter'),
    engine: engine,
    options: {
        width: reWi,
        height: reHi,
        wireframes: false,
        showAngleIndicator: true,
        showCollisions: true,
        showVelocity: true,
        hasBounds: true
    }
});
Render.run(render);

// create runner
var runner = Runner.create();
Runner.run(runner, engine);

// add mouse control
var mouse = Mouse.create(render.canvas),
mouseConstraint = MouseConstraint.create(engine, {
    mouse: mouse,
    constraint: {
        stiffness: 0.6,
        render: {
            visible: true
        }
    }
});
World.add(world, mouseConstraint);
// keep the mouse in sync with rendering
render.mouse = mouse;

// fit the render viewport to the scene
Render.lookAt(render, {
    min: { x: 0, y: 0 },
    max: { x: reWi, y: reHi }
});

world.gravity.y = GRAVITY;

/*
*   Actual physics objects
*/
var w_bot = buildRect(reWi*0.5, reHi, reWi, reHi/10, { 
  label: 'floor',
  isStatic: true
});
var w_left = buildRect(0, reHi*0.5, reWi/10, reHi, {
  label: "wall",
  isStatic: true
});
var w_right = buildRect(reWi, reHi*0.5, reWi/10, reHi, {
  label: "wall",
  isStatic: true
});
World.add(world, [
  w_bot,
  w_left,
  w_right
]);

var stackDropper = buildRect(reWi*0.5, 20, reWi*0.75, 20, {
  label: "stackDropper",
  isSensor: true,
  render: {
    fillStyle: '#c0ffc0'
  },
  canDrop: true //custom property
});
World.add(world, [stackDropper]);

var rock = Bodies.polygon(reWi*0.5, pcHeight(0.9), 7, 80, { 
  chamfer: { radius: [0, 40, 0, 0, 0, 0, 10] },
  isStatic: true,
  label: 'validGoal'
});
var tower = Composite.create();
Composite.add(tower, rock);
World.add(world, tower);

/*
*   Functions
*/
//drop a brick
function dropItem() {
  dropperState(false);
  World.add(world, buildRect(stackDropper.position.x, 20, (stackDropper.bounds.max.x - stackDropper.bounds.min.x), 30, { label: "stackItem" }));
}

//brick dropping allowed?
function dropperState(allow) {
  stackDropper.canDrop = allow;
  if(allow){
    stackDropper.render.fillStyle = '#c0ffc0';
  }else{
    stackDropper.render.fillStyle = '#ffc0c0';
  }
}

//stackItem touches floor; game over. stackItem touches stackedItem, make it static and re-label it as stackedItem
function collisionHandler(stackItem, bodyB){
  switch (bodyB.label) {
    case 'validGoal':
      stopAndScore(stackItem, bodyB);
      break;
    case 'stackedItem':
    case 'floor':
      gameOver();
      break;
  }
}

function gameOver() {
  World.remove(world, [stackDropper]);
  document.querySelector('.gameOver').dataset.show = 1;
}

function stopAndScore(stackItem, bodyB) {
  stackItem.render.fillStyle = COLOR_GOAL;
  stackItem.label = 'validGoal';
  Body.setStatic(stackItem, true);

  bodyB.render.fillStyle = COLOR_STACKED;
  bodyB.label = 'stackedItem';

  var dropScore = BASE_SCORE;
  var diff = 0;
  var goalWidth = bodyB.bounds.max.x - bodyB.bounds.min.x;
  var stackWidth = stackItem.bounds.max.x - stackItem.bounds.min.x;
  if( goalWidth >= stackWidth ){
    if( stackItem.bounds.max.x > bodyB.bounds.max.x ){//too far to the right
      diff = stackItem.bounds.max.x - bodyB.bounds.max.x;
    }else if( stackItem.bounds.min.x < bodyB.bounds.min.x ){//too far to the left
      diff = bodyB.bounds.min.x - stackItem.bounds.min.x;
    }
    score_global += (1-(diff/goalWidth)) * dropScore;
  }else{
    score_global += 1000;
  }
  
  //DOM manipulation
  for( scoreDOM of document.querySelectorAll('.score') ){
    scoreDOM.innerText = Math.floor(score_global);
  }

  tower_grow(stackItem);

  var dropDistance = (1-(diff/goalWidth)) * DROPRATE;
  tower_lower(dropDistance);

  var scaling = Math.random() * (0.99 - 0.95) + 0.95;
  Body.scale(stackDropper, scaling, 1);
}

function tower_grow(stackItem) {
  Composite.add(tower, stackItem);
}
function tower_lower(dropDistance) {
  Composite.translate(tower, {x:0, y: dropDistance});
  if( Composite.bounds(tower).max.y > reHi-50 ){// garbage collect at a height of reHi-50
    var towerPieces = Composite.allBodies(tower);
    for( junk of towerPieces){
      if( junk.bounds.min.y > (reHi-50) ){
        Composite.remove(tower, junk);
        World.remove(world, junk);
      }
    }
  }
}
function tower_raise() {
  Composite.translate(tower, {x:0, y: -1});
  if( Composite.bounds(tower).min.y < 0 ){
    gameOver();
  }
}

document.addEventListener("keydown", function(e){
  switch (e.keyCode) {
    case 67: // c
      if( stackDropper.canDrop ){
        dropItem();
      }//else raise level?
      break;
    case 82: // r
      location.reload();
      break;
    default:
      console.log(e.keyCode);
      break;
  }
});

/*
*   Lifecycle events
*/
var counter = 0;
var midPoint = reWi * 0.5;
Events.on(engine, 'beforeUpdate', function(event) {
  counter++;
  var px = midPoint + ( midPoint * Math.sin(engine.timing.timestamp * 0.002) * 0.9 );
  //-1 to 1; console.log(Math.sin(engine.timing.timestamp*0.002));
  Body.setPosition(stackDropper, { y: 20, x: px });
  for( levelDOM of document.querySelectorAll('.level') ){
    levelDOM.innerText = Math.floor(reHi - Composite.bounds(tower).min.y);
  }

  if( counter >= RAISE_RATE ){
    counter = 0;
    tower_raise();
  }
});

Events.on(engine, 'collisionStart', function(event) {
  for( pair of event.pairs ){
    //console.log(pair.bodyA.label, pair.bodyB.label);
    //resetting "a" and "b"
    if( pair.bodyA.label === 'stackItem' ){
      collisionHandler(pair.bodyA, pair.bodyB);
    }else if( pair.bodyB.label === 'stackItem' ){
      collisionHandler(pair.bodyB, pair.bodyA);
    }
    if(( pair.bodyA.label === 'stackDropper' && pair.bodyB.label === 'wall' ) || ( pair.bodyB.label === 'stackDropper' && pair.bodyA.label === 'wall' )){
      dropperState(false);
    }
  }
});

Events.on(engine, 'collisionEnd', function(event) {
  for( pair of event.pairs ){
    //console.log(pair.bodyA.label, pair.bodyB.label);
    //resetting "a" and "b"
    if(( pair.bodyA.label === 'stackDropper' && pair.bodyB.label === 'wall' ) || ( pair.bodyB.label === 'stackDropper' && pair.bodyA.label === 'wall' )){
      dropperState(true);
    }
  }
});

/*
*   Rendering
*/
Events.on(render, 'afterRender', function() {
  var context = render.context;
  let towerBottom = Composite.bounds(tower).min.y + 100;

  Render.startViewTransform(render);

  context.beginPath();
  context.moveTo(0, towerBottom);
  context.lineTo(reWi, towerBottom);
  context.lineTo(reWi, reHi);
  context.lineTo(0, reHi);
  context.strokeStyle = '#11027cde';
  context.lineWidth = 2;
  context.stroke();
  context.fillStyle = '#11027cde';
  context.fill();

  context.beginPath();
  context.moveTo(stackDropper.bounds.min.x, stackDropper.position.y);
  context.lineTo(stackDropper.bounds.min.x, towerBottom);
  context.lineTo(stackDropper.bounds.max.x, towerBottom);
  context.lineTo(stackDropper.bounds.max.x, stackDropper.position.y);
  context.fillStyle = '#ffffff11';
  context.fill();

  Render.endViewTransform(render);
  //render ocean at Composite.bounds(tower).max.y ?
});