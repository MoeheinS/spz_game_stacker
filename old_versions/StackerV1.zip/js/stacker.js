console.log('%cStacker game','color:#ff0000;font-family:Comic Sans MS;');

let score = 0;
const DROPRATE = 20;
const GRAVITY = 0.75;

world.gravity.y = GRAVITY;

// create walls and add them to the world
var w_top = buildRect(reWi*0.5, 0, reWi, reHi/10, staticOption);
var w_bot = buildRect(reWi*0.5, reHi, reWi, reHi/10, staticOption);
w_bot.label = 'floor';
var w_left = buildRect(0, reHi*0.5, reWi/10, reHi, {
  label: "wall",
  isStatic: true
});
var w_right = buildRect(reWi, reHi*0.5, reWi/10, reHi, {
  label: "wall",
  isStatic: true
});

World.add(world, [
  //w_top,
  w_bot,
  w_left,
  w_right
]);

//create the stackable thing we'll drop
//function gameLoop() {
function dropItem() {
  dropperState(stackDropper, 'disable');
  var stackItem = buildRect(
    stackDropper.position.x, 20, 
    (stackDropper.bounds.max.x - stackDropper.bounds.min.x), 30, 
    {
      label: "stackItem"
    }
  );
  World.add(world, [stackItem]);
}

var maxWide = reWi-(reWi/9);
var stackDropper = buildRect(reWi*0.5, 20, maxWide*Math.random(), 20, {
  label: "stackDropper",
  //isStatic: true,
  isSensor: true,
  render: {
    fillStyle: '#c0ffc0'
  },
  canDrop: true
});
World.add(world, [stackDropper]);

var counter = 0;
var midPoint = reWi * 0.5;
Events.on(engine, 'beforeUpdate', function(event) {
  counter = counter + 1;
  // if body is static, manually update velocity for friction to work
  var px = midPoint + ( midPoint * Math.sin(engine.timing.timestamp * 0.002) * 0.9 );
  //-1 to 1; console.log(Math.sin(engine.timing.timestamp*0.002));
  //Body.setVelocity(stackDropper, { y: 0, x: px - stackDropper.position.x });
  Body.setPosition(stackDropper, { y: 20, x: px });

  if( counter >= 30 ){
    counter = 0;
    Composite.translate(tower, {x:0, y: -1});

    var towerPieces = Composite.allBodies(tower);
    for( junk of towerPieces){
      if( junk.bounds.min.y < 0 ){
        World.remove(world, [stackDropper]);
        document.querySelector('.gameOver').dataset.show = 1;
      }
    }
  }
});

// collision events
Matter.Events.on(engine, 'collisionStart', function(event) {
  let pairs = event.pairs;
  pairs.forEach(function(pair) {
    console.log(pair.bodyA.label, pair.bodyB.label);
    //resetting "a" and "b"
    if (pair.bodyA.label === 'stackItem') {
      collisionHandler(pair.bodyA, pair.bodyB);
    }else if (pair.bodyB.label === 'stackItem') {
      collisionHandler(pair.bodyB, pair.bodyA);
    }

    if (pair.bodyA.label === 'stackDropper' && pair.bodyB.label === 'wall') {
      dropperState(pair.bodyA, 'disable');
    }else if (pair.bodyB.label === 'stackDropper' && pair.bodyA.label === 'wall') {
      dropperState(pair.bodyB, 'disable');
    }
  });
});

Matter.Events.on(engine, 'collisionEnd', function(event) {
  let pairs = event.pairs;
  pairs.forEach(function(pair) {
    //console.log(pair.bodyA.label, pair.bodyB.label);
    //resetting "a" and "b"
    if (pair.bodyA.label === 'stackDropper' && pair.bodyB.label === 'wall') {
      dropperState(pair.bodyA, 'enable');
    }else if (pair.bodyB.label === 'stackDropper' && pair.bodyA.label === 'wall') {
      dropperState(pair.bodyB, 'enable');
    }
    //this might be better with a double ternary operator
  });
});

function dropperState(bodyA, watDo) {
  if(watDo == 'disable'){
    bodyA.canDrop = false;
    bodyA.render.fillStyle = '#ffc0c0';
  }else if(watDo == 'enable'){
    bodyA.canDrop = true;
    bodyA.render.fillStyle = '#c0ffc0';
  }
  //console.log(bodyA);
}

//stackItem touches floor; game over. stackItem touches stackedItem, make it static and re-label it as stackedItem
//then restart the gameloop
function collisionHandler(stackItem, bodyB){
  switch (bodyB.label) {
    case 'validGoal':
      stopAndScore(stackItem, bodyB);
      break;
    case 'stackedItem':
    case 'floor':
      World.remove(world, [stackDropper]);
      document.querySelector('.gameOver').dataset.show = 1;
      //location.reload();
      break;
  }
}

function stopAndScore(stackItem, bodyB) {
  stackItem.render.fillStyle = '#fcfcfc';
  stackItem.label = 'validGoal';
  Body.setStatic(stackItem, true);

  bodyB.render.fillStyle = '#fc0c0c';
  bodyB.label = 'stackedItem';
  //todo scoring based on width? narrower = more score

  var dropScore = 1000;
  var diff = 0;
  var goalWidth = bodyB.bounds.max.x - bodyB.bounds.min.x;
  if( stackItem.bounds.max.x > bodyB.bounds.max.x ){//too far to the right
    diff = stackItem.bounds.max.x - bodyB.bounds.max.x;
  }else if( stackItem.bounds.min.x < bodyB.bounds.min.x ){//too far to the left
    diff = bodyB.bounds.min.x - stackItem.bounds.min.x;
  }
  score += (1-(diff/goalWidth)) * dropScore;
  document.querySelector('.container__Stats').innerText = `score: ${Math.floor(score)}`;
  document.querySelector('.score').innerText = Math.floor(score);

  Composite.add(tower, stackItem);
  var dropDistance = (1-(diff/goalWidth)) * DROPRATE;
  Composite.translate(tower, {x:0, y: dropDistance});

  var towerPieces = Composite.allBodies(tower);
  for( junk of towerPieces){
    if( junk.bounds.min.y > (reHi-50) ){
      Composite.remove(tower, junk);
      World.remove(world, junk);
    }
  }

  var scaling = Math.random() * (0.99 - 0.95) + 0.95;
  Body.scale(stackDropper, scaling, 1);
}

var rock = Bodies.polygon(pcWidth(0.5), pcHeight(0.9), 7, 80, { 
  chamfer: { radius: [0, 40, 0, 0, 0, 0, 10] },
  isStatic: true,
  label: 'validGoal'
});
rock.restitution = 1.5;
//World.add(world, rock);
var tower = Composite.create();
Composite.add(tower, rock);
World.add(world, tower);

document.addEventListener("keydown", function(e){
  console.log(e.keyCode);
  //90 & 37 ; left
  //88 & 39 ; right
  //67 ; c

  if(e.keyCode == 90 || e.keyCode == 37){
    // Body.setAngularVelocity( flipper_l, Math.PI/12);
    // Body.setAngularVelocity( flipper_r, -Math.PI/12);
  }
  if(e.keyCode == 88 || e.keyCode == 39){
    // Body.setAngularVelocity( flipper_l, -Math.PI/12);
    // Body.setAngularVelocity( flipper_r, Math.PI/12);
  }
  if(e.keyCode == 67){
    if( stackDropper.canDrop ){
      dropItem();
    }
  }
  if(e.keyCode == 82){
    location.reload();
  }
});

Events.on(render, 'afterRender', function() {
  var context = render.context;

  Render.startViewTransform(render);

  context.beginPath();
  context.moveTo(0, reHi*0.3);
  context.lineTo(reWi, reHi*0.3);

  context.moveTo(0, reHi*0.6);
  context.lineTo(reWi, reHi*0.6);

  context.moveTo(0, reHi-40);
  context.lineTo(reWi, reHi-40);

  context.moveTo(stackDropper.position.x, stackDropper.position.y);
  context.lineTo(stackDropper.position.x, reHi);
  context.strokeStyle = '#555';
  context.lineWidth = 0.5;
  context.stroke();

  context.fillStyle = 'rgba(255,165,0,0.7)';
  context.fill();

  Render.endViewTransform(render);
});